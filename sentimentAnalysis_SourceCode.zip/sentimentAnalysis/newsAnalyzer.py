#!/usr/bin/env python
import json
import sys
import requests
from datetime import date
from datetime import datetime
import redis
import os
import logging
from classifier.forest import RandomForest
from preprocess import features

base_path = os.path.abspath(__file__ + "/../")

#print "base path",base_path

# create logger
logger = logging.getLogger('newsAnalyzer')
logger.setLevel(logging.DEBUG)

# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)

logger.info("News analysis started")

number_of_trees = 24
size = 'medium'
forest_file = base_path+'/data/classifiers/%i_trees_%s_training.txt' %(number_of_trees, size)
data_features_file = base_path+'/data/features.txt'
#test_json_path = 'data/json_files/arts.json'
db_conn_news = redis.StrictRedis(host='localhost', port=6379, db=2)

def get_features():
	fs = []
	
	f = open(data_features_file, 'r+')
	for line in f:
		fs.append(line.strip())
	f.close()
	return fs

currentDate = str(date.today())
curfilePath = os.path.abspath(__file__)
curDir = os.path.abspath(os.path.join(curfilePath,os.pardir))
todays_json_path = os.path.abspath(os.path.join(curDir,os.pardir))
with open(todays_json_path+"/output/news_for_the_day.json") as data:
	json_data = json.load(data)
	#print json_data
	data.close()

# Performing sentimental analysis to find positive news and update news polarity accordingly
forest = RandomForest.load(forest_file)
#list_of_ids = [i for i in range(1,len(json_data))]
i = 0
positiveNews_cnt = 0
for todo_item in json_data:
	#print('{} {}'.format(todo_item['polarity'], todo_item['news']))
	text = (todo_item['news']).encode('utf-8')
	#date = time.strftime("%x")
	i = i+1
	todo_item['newsId'] = currentDate+'_'+str(i)
	f = get_features()
	f.remove('star')
	processed_text = dict(zip(f, features.extract(text)))
	answer = forest.classify(processed_text)
	#print(answer)
		#if answer < 3:
	#	todo_item['polarity'] = -1
	if answer > 3:
		positiveNews_cnt += 1
		#print 'test'
		todo_item['polarity'] = 1
		db_conn_news.hmset(todo_item['newsId'], todo_item)
logger.info("Total count of positive news inserted into DB is : "+str(positiveNews_cnt))
logger.info("News analysis ended")
	
# Saving news with updated polarity (-1.0/1.0) to database
#headers = {'Content-Type': 'application/json'}
#r = requests.post('http://localhost:14080/datalayer/updateAllNewsItems', json=json_data, headers=headers)
#if r.status_code == 200:
#	print('true')
