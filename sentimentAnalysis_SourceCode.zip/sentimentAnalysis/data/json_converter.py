'''
Fields in outPut_file:
id
day
title
news
newsCategory
newsChannel
polarity
timestamp
'''
import json
from pprint import pprint

with open('/home/nextremer/Downloads/File1_Before_17May2016.json') as data_file:
	data = json.load(data_file)
	data_op = {
		'_id':'',
		'_class':'',
		'day':'',
		'title':data[Title],
		'news':data[News],
		'newsCategory':'',
		'newsChannel':'',
		'polarity':data [Polarity],
		'timestamp':''
	}
	with open('/home/nextremer/Downloads/File1_Before_17May2016_conv.json', 'w+') as f:
		json.dump(data_op, f)

		
pprint(data_op)