import sys
import json
import os

from classifier.forest import RandomForest
from preprocess import features
path = r"/home/nextremer/inspireindia/sentimentAnalysis/data/json/"
number_of_trees = 24
size = 'medium'
forest_file = '/home/nextremer/inspireindia/sentimentAnalysis/data/classifiers/%i_trees_%s_training.txt' %(number_of_trees, size)
data_features_file = '/home/nextremer/inspireindia/sentimentAnalysis/data/features.txt'

def get_features():
	fs = []
	
	f = open(data_features_file, 'r+')
	for line in f:
		fs.append(line.strip())
	f.close()

	return fs

if __name__ == '__main__':

	forest = RandomForest.load(forest_file)
	for file in os.listdir(path):
		current_file = os.path.join(path, file)
		print current_file
		data_file = open(current_file, "rb")
		print data_file
		num = sum(1 for line in open(current_file))
		print num
		data_json = json.load(data_file)
		for i in range(0,num-1):
			#print data_json[i]["news"]
			text = (data_json[i]["news"]).encode('utf-8')
	
			#print text

			f = get_features()
			f.remove('star')
			processed_text = dict(zip(f, features.extract(text)))

			answer = forest.classify(processed_text)

			if answer < 3:
				data_json[i]["polarity"]="-1"
			elif answer > 3:
				data_json[i]["polarity"]="1"
			else:
				break;
